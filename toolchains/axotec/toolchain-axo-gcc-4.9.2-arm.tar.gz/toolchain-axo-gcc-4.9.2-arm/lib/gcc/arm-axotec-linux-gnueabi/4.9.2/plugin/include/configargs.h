/* Generated automatically. */
static const char configuration_arguments[] = "./configure --prefix=/usr/local/arm/4.9.2/usr --sysconfdir=/usr/local/arm/4.9.2/etc --enable-static --target=arm-axotec-linux-gnueabi --with-sysroot=/usr/local/arm/4.9.2/usr/arm-axotec-linux-gnueabi/sysroot --disable-__cxa_atexit --with-gnu-ld --disable-libssp --disable-multilib --with-gmp=/usr/local/arm/4.9.2/usr --with-mpfr=/usr/local/arm/4.9.2/usr --enable-target-optspace --disable-libquadmath --enable-tls --disable-libmudflap --enable-threads --with-mpc=/usr/local/arm/4.9.2/usr --without-isl --without-cloog --with-float=soft --disable-decimal-float --with-abi=aapcs-linux --with-cpu=arm926ej-s --with-float=soft --with-mode=arm --with-pkgversion='Buildroot 2015.02' --with-bugurl=http://bugs.buildroot.net/ --enable-languages=c,c++ --enable-poison-system-directories --with-build-time-tools=/usr/local/arm/4.9.2/usr/arm-axotec-linux-gnueabi/bin --enable-shared --enable-libgomp";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "aapcs-linux" }, { "cpu", "arm926ej-s" }, { "float", "soft" }, { "mode", "arm" }, { "tls", "gnu" } };
